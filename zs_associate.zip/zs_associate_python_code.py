#!/usr/bin/env python
# coding: utf-8

# # Welcome to Jupyter!

# In[4]:


#In[7]:


import pandas as pd
import numpy as np
import os


# In[8]:


os.getcwd()


# In[9]:


import warnings
warnings.filterwarnings("ignore")


# In[10]:


train=pd.read_csv('train.csv')


# In[11]:


test=pd.read_csv('test.csv')


# In[12]:


train.head()


# In[13]:


test.head()


# In[14]:


train.shape


# In[15]:


test.shape


# In[16]:


train.dtypes


# In[17]:


train = train.fillna(train.mean())


# In[18]:


test=test.fillna(test.mean())


# In[19]:


X = train.iloc[:,1:24]


# In[20]:


X.head()


# In[21]:


y = train.iloc[:,24]


# In[22]:


X_t=test.iloc[:,1:24]


# In[25]:


from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)


# In[24]:


from sklearn.ensemble import RandomForestRegressor

regressor = RandomForestRegressor(n_estimators=100, random_state=0)  
regressor.fit(X_train, y_train)  
y_pred = regressor.predict(X_test) 


# In[21]:


from sklearn import metrics

print('Mean Absolute Error:', metrics.mean_absolute_error(y_test, y_pred))  
print('Mean Squared Error:', metrics.mean_squared_error(y_test, y_pred))  
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y_test, y_pred)))  


# In[26]:


X_t.shape


# In[28]:


test.shape


# In[29]:


predtest=regressor.predict(X_t)


# In[33]:


sol=pd.DataFrame()


# In[34]:


sol['soldierId']=test.soldierId


# In[35]:


pred= pd.DataFrame(predtest)


# In[36]:


pred.head()


# In[37]:


sol['bestSoldierPerc']=pred.iloc[:,0]


# In[38]:


sol.head()


# In[39]:


sol.shape


# In[40]:


test.shape


# In[42]:


sol.to_csv('submission_file.csv',index=False)


# This repo contains an introduction to [Jupyter](https://jupyter.org) and [IPython](https://ipython.org).
# 
# Outline of some basics:
# 
# * [Notebook Basics](../examples/Notebook/Notebook%20Basics.ipynb)
# * [IPython - beyond plain python](../examples/IPython%20Kernel/Beyond%20Plain%20Python.ipynb)
# * [Markdown Cells](../examples/Notebook/Working%20With%20Markdown%20Cells.ipynb)
# * [Rich Display System](../examples/IPython%20Kernel/Rich%20Output.ipynb)
# * [Custom Display logic](../examples/IPython%20Kernel/Custom%20Display%20Logic.ipynb)
# * [Running a Secure Public Notebook Server](../examples/Notebook/Running%20the%20Notebook%20Server.ipynb#Securing-the-notebook-server)
# * [How Jupyter works](../examples/Notebook/Multiple%20Languages%2C%20Frontends.ipynb) to run code in different languages.

# You can also get this tutorial and run it on your laptop:
# 
#     git clone https://github.com/ipython/ipython-in-depth
# 
# Install IPython and Jupyter:
# 
# with [conda](https://www.anaconda.com/download):
# 
#     conda install ipython jupyter
# 
# with pip:
# 
#     # first, always upgrade pip!
#     pip install --upgrade pip
#     pip install --upgrade ipython jupyter
# 
# Start the notebook in the tutorial directory:
# 
#     cd ipython-in-depth
#     jupyter notebook
